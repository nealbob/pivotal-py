from .dsl_parser import DSLParser, load_functions
from .package import Package
from .magic import update, delete, plot_gui, pivot_gui, load_gui, save_gui, settings_gui
from .errors import PivotalError, display_error, format_error_text, format_error_html, _translate_runtime_error
from .runner import (
    compare_pandas_to_pivotal,
    compare_pandas_to_pivotal_isolated,
    run_pivotal,
    run_pivotal_isolated,
)

def load_ipython_extension(ipython):
    from .magic import load_ipython_extension as magic_load
    magic_load(ipython)

# Auto-register the IPython magic when imported inside a Jupyter/IPython session.
# This means %%pivotal works immediately without requiring %load_ext pivotal.
try:
    ip = get_ipython()  # type: ignore[name-defined]
    if ip is not None:
        from .magic import PivotalMagics, _active_magics as _am
        import pivotal.magic as _magic_mod
        if _am is None:
            m = PivotalMagics(ip)
            _magic_mod._active_magics = m
            ip.register_magics(m)
except NameError:
    pass  # Not running inside IPython

__all__ = ['DSLParser', 'Package', 'load_functions', 'load_ipython_extension', 'update', 'delete',
           'plot_gui', 'pivot_gui', 'load_gui', 'save_gui', 'settings_gui',
           'PivotalError', 'display_error', 'format_error_text', 'format_error_html',
           'run_pivotal', 'run_pivotal_isolated', 'compare_pandas_to_pivotal',
           'compare_pandas_to_pivotal_isolated']
